﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using UnityEngine.Events;
using System;

public class UIController : MonoBehaviour, IUIController
{

    #region Private variables to reference UI components/gameController

    private GameController gameController;

    private GameObject[] panels;
    private static string activePanel = "GameInfoPanel";


    private Button[] buttons;
    private Text[] labels;
    private GameObject[] toggles;         
    private Button btnRestartGame;
    private Button btnRestoreDefaults;
    private Button btnRuleOne;
    private Button btnRuleTwo;
    private Button btnRuleThree;
    private Button btnRuleFour;
    private Button btnGameInfo;
    private Button btnExit;
    private Slider speedSlider;
    private Toggle randomToggle;
    private Toggle aliveToggle;
    private Toggle deadToggle;
    private InputField numCubesX;
    private InputField numCubesY;
    private Text lblRuleText;

    private Dropdown ruleNumberOneState;
    private Dropdown ruleNumberOneFilterValue;
    private Dropdown ruleNumberOneResultingState;

    private Dropdown ruleNumberTwoState;
    private Dropdown ruleNumberTwoFilterValue1;
    private Dropdown ruleNumberTwoFilterValue2;
    private Dropdown ruleNumberTwoResultingState;

    private Dropdown ruleNumberThreeState;
    private Dropdown ruleNumberThreeFilterValue;
    private Dropdown ruleNumberThreeResultingState;

    private Dropdown ruleNumberFourState;
    private Dropdown ruleNumberFourFilterValue;
    private Dropdown ruleNumberFourResultingState;

    public string stateString;
    public string filterValue1;
    public string filterValue2;
    public string resultState;
    #endregion
    private void Awake()
    {
        // we will reserve Awake() for GameController activity to avoid execution order conflicts.
    }   
    void Start ()
    {
        
    }	
	void Update ()
    {
		
	}
    #region Initialization Methods

    void InitializePanels()
    {
        // create an array of UI panels to toggle through.

        
        panels = GameObject.FindGameObjectsWithTag("RulePanel");
        lblRuleText = GameObject.FindGameObjectWithTag("RuleLabel").GetComponent<Text>();
        for (int i = 0; i < panels.Length; i++)
        {
            CanvasGroup canvasGroup = panels[i].GetComponent<CanvasGroup>();
            if (panels[i].name != activePanel)
            {   // this makes a panel invisible.
                canvasGroup.alpha = 0;
                canvasGroup.blocksRaycasts = false;
            }
            else
            {   // this makes a panel visible.
                canvasGroup.alpha = 1f;
                canvasGroup.blocksRaycasts = true;
            }
        }

                
    }
    void InitializeToggles()
    {
        // creates an array of gameobjects tagged "Toggle"
        toggles = GameObject.FindGameObjectsWithTag("Toggle");

        //return the first toggle (tog) named "Xxxxx" or return null
        randomToggle = toggles.FirstOrDefault(tog => tog.name == "Random").GetComponent<Toggle>();
        aliveToggle = toggles.FirstOrDefault(tog => tog.name == "Alive").GetComponent<Toggle>();
        deadToggle = toggles.FirstOrDefault(tog => tog.name == "Dead").GetComponent<Toggle>();
    }

    void InitializeButtons()
    {
        // creates array of objects of type "Button"
        buttons = UnityEngine.Object.FindObjectsOfType<Button>();
        labels = UnityEngine.Object.FindObjectsOfType<Text>();
        

        // return the first button (btn) named "xxxx" or return null
        btnRestartGame = buttons.FirstOrDefault(btn => btn.name == "btnRestartGame").GetComponent<Button>();
        btnRestoreDefaults = buttons.FirstOrDefault(btn => btn.name == "btnRestoreDefaults").GetComponent<Button>();
        btnRuleOne = buttons.FirstOrDefault(btn => btn.name == "btnRuleOne").GetComponent<Button>();
        btnRuleTwo = buttons.FirstOrDefault(btn => btn.name == "btnRuleTwo").GetComponent<Button>();
        btnRuleThree = buttons.FirstOrDefault(btn => btn.name == "btnRuleThree").GetComponent<Button>();
        btnRuleFour = buttons.FirstOrDefault(btn => btn.name == "btnRuleFour").GetComponent<Button>();
        btnGameInfo = buttons.FirstOrDefault(btn => btn.name == "btnGameInfo").GetComponent<Button>();
        btnExit = buttons.FirstOrDefault(btn => btn.name == "btnExit").GetComponent<Button>();
        
        // add onclick events for buttons.
        UnityAction restart = new UnityAction(Restart);
        //UnityAction togglePanel = new UnityAction(TogglePanel);
        UnityAction panelOne = new UnityAction(ToggleOne);
        UnityAction panelTwo = new UnityAction(ToggleTwo);
        UnityAction panelThree = new UnityAction(ToggleThree);
        UnityAction panelFour = new UnityAction(ToggleFour);
        UnityAction resetSettings = new UnityAction(ResetDefaults);
        UnityAction gameInfo = new UnityAction(ToggleInfo);
        UnityAction quitGame = new UnityAction(ExitGame);
        btnRestartGame.onClick.AddListener(restart);
        //btnTogglePanel.onClick.AddListener(togglePanel);
        btnRuleOne.onClick.AddListener(panelOne);
        btnRuleTwo.onClick.AddListener(panelTwo);
        btnRuleThree.onClick.AddListener(panelThree);
        btnRuleFour.onClick.AddListener(panelFour);
        btnRestoreDefaults.onClick.AddListener(ResetDefaults);
        btnGameInfo.onClick.AddListener(gameInfo);
        btnExit.onClick.AddListener(quitGame);



        

        Dropdown[] dropdowns = UnityEngine.Object.FindObjectsOfType<Dropdown>();
        Dropdown dd;

        for (int i = 0; i < dropdowns.Length; i++)
        {
            dd = dropdowns[i];
            dd.onValueChanged.AddListener(delegate {
                UpdateRuleText();
            });
        }

    
    }

   


    void InitializeDropdowns()
    {
        // the canvas is the parent of all UI elements.
        Canvas canvas = UnityEngine.Object.FindObjectOfType<Canvas>();

        // from the Dropdown type children of canvas, return the first dropdown named "xxxx" or return null
        ruleNumberOneState = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberOneState").FirstOrDefault();
        ruleNumberOneFilterValue = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberOneFilterValue").FirstOrDefault();
        ruleNumberOneResultingState = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberOneResultingState").FirstOrDefault();

        ruleNumberTwoState = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberTwoState").FirstOrDefault();
        ruleNumberTwoFilterValue1 = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberTwoFilterValue1").FirstOrDefault();
        ruleNumberTwoFilterValue2 = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberTwoFilterValue2").FirstOrDefault();
        ruleNumberTwoResultingState = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberTwoResultingState").FirstOrDefault();

        ruleNumberThreeState = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberThreeState").FirstOrDefault();
        ruleNumberThreeFilterValue = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberThreeFilterValue").FirstOrDefault();
        ruleNumberThreeResultingState = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberThreeResultingState").FirstOrDefault();
        
        ruleNumberFourState = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberFourState").FirstOrDefault();
        ruleNumberFourFilterValue = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberFourFilterValue").FirstOrDefault();
        ruleNumberFourResultingState = canvas.GetComponentsInChildren<Dropdown>().Where(dd => dd.name == "ruleNumberFourResultingState").FirstOrDefault();
    }

    void InitializeInputFields()
    {
        // create an array of input field objects.
        InputField[] inputFields = UnityEngine.Object.FindObjectsOfType<InputField>();

        // from the array, return the first object named "xxx" or return null.
        numCubesX = inputFields.Where(input => input.name == "numCubesX").FirstOrDefault();
        numCubesY = inputFields.Where(input => input.name == "numCubesY").FirstOrDefault();        
    }

    public void InitializeUI()
    {   // gets called by the Game Controller.
        gameController = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameController>();


        // create array of Slider objects, get the first one named "xxx", get its Slider component, or return null
        speedSlider = GameObject.FindObjectsOfType<Slider>().FirstOrDefault(sldr => sldr.name == "UpdateStateRateLimit").GetComponent<Slider>();
        
        InitializeButtons();
        InitializeDropdowns();
        InitializePanels();
        InitializeDropdowns();
        InitializeToggles();
        InitializeInputFields();

        //btnRuleOne.Select();
    }

    #endregion

    #region UI Control Methods
    /*void TogglePanel()
    {
        // checks the current panel name and determines which panel to make visible next.
        string newPanel;
        int newPanelIndex = 0;
        int oldPanelIndex = 0;
        if (activePanel == "RuleNumberOne")
        {
            newPanel = "RuleNumberTwo";
        }
        else if (activePanel == "RuleNumberTwo")
        {
            newPanel = "RuleNumberThree";
        }
        else if (activePanel == "RuleNumberThree")
        {
            newPanel = "RuleNumberFour";
        }
        else if (activePanel == "RuleNumberFour")
        {
            newPanel = "RuleNumberOne";
        }

        for (int i = 0; i < panels.Length; i++)
        {
            if (panels[i].name == newPanel)
            {
                newPanelIndex = i;
            }

            if (panels[i].name == activePanel)
            {
                oldPanelIndex = i;
            }
        }

        // make the old panel invisible and the new panel visible.
        CanvasGroup oldPanelCG = panels[oldPanelIndex].GetComponent<CanvasGroup>();
        CanvasGroup newPanelCG = panels[newPanelIndex].GetComponent<CanvasGroup>();
        oldPanelCG.alpha = 0f;
        oldPanelCG.blocksRaycasts = false;

        newPanelCG.alpha = 1f;
        newPanelCG.blocksRaycasts = true;
        activePanel = panels[newPanelIndex].name;
    }*/

    void UpdateRuleText()
    {

       
            GameObject rulePanel = panels.FirstOrDefault(pnl => pnl.name == activePanel);
            

        if (lblRuleText != null)
        {
            Dropdown[] dropdowns;

            int startingState;
            int filterValue1;
            int filterValue2;
            int resultingState;

            Dropdown ddStartingState;
            Dropdown ddFilterValue1;
            Dropdown ddFilterValue2;
            Dropdown ddResultingState;

            dropdowns = UnityEngine.Object.FindObjectsOfType<Dropdown>();


            if (activePanel == "RuleNumberTwo")
            {
                ddStartingState = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberTwoState");
                startingState = ddStartingState.value;

                ddFilterValue1 = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberTwoFilterValue1");
                filterValue1 = ddFilterValue1.value;

                ddFilterValue2 = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberTwoFilterValue2");
                filterValue2 = ddFilterValue2.value;

                ddResultingState = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberTwoResultingState");
                resultingState = ddResultingState.value;

                lblRuleText.text = "if (this.State == " + startingState + " && numLiveNeighbors >= " + filterValue1 + " && numLiveNeighbors <= " + filterValue2 + ")";
                lblRuleText.text += "\n";
                lblRuleText.text += "{";
                lblRuleText.text += "\n\t";
                lblRuleText.text += "this.NextState = " + resultingState + ";\n}";

            }
            else if (activePanel == "RuleNumberOne")
            {
                ddStartingState = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberOneState");
                startingState = ddStartingState.value;

                ddFilterValue1 = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberOneFilterValue");
                filterValue1 = ddFilterValue1.value;

                ddResultingState = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberOneResultingState");
                resultingState = ddResultingState.value;

                lblRuleText.text = "if (this.State == " + startingState + " && numLiveNeighbors > " + filterValue1 + ")";
                lblRuleText.text += "\n";
                lblRuleText.text += "{";
                lblRuleText.text += "\n\t";
                lblRuleText.text += "this.NextState = " + resultingState + ";\n}";
            }
            else if (activePanel == "RuleNumberThree")
            {
                ddStartingState = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberThreeState");
                startingState = ddStartingState.value;

                ddFilterValue1 = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberThreeFilterValue");
                filterValue1 = ddFilterValue1.value;

                ddResultingState = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberThreeResultingState");
                resultingState = ddResultingState.value;

                lblRuleText.text = "if (this.State == " + startingState + " && numLiveNeighbors > " + filterValue1 + ")";
                lblRuleText.text += "\n";
                lblRuleText.text += "{";
                lblRuleText.text += "\n\t";
                lblRuleText.text += "this.NextState = " + resultingState + ";\n}";
            }
            else if (activePanel == "RuleNumberFour")
            {
                ddStartingState = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberFourState");
                startingState = ddStartingState.value;

                ddFilterValue1 = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberFourFilterValue");
                filterValue1 = ddFilterValue1.value;

                ddResultingState = dropdowns.FirstOrDefault(dd => dd.name == "ruleNumberFourResultingState");
                resultingState = ddResultingState.value;

                lblRuleText.text = "if (this.State == " + startingState + " && numLiveNeighbors == " + filterValue1 + ")";
                lblRuleText.text += "\n";
                lblRuleText.text += "{";
                lblRuleText.text += "\n\t";
                lblRuleText.text += "this.NextState = " + resultingState + ";\n}";
            }

            else if (activePanel == "GameInfoPanel")
            {
                lblRuleText.text = "Can you devise a set of rules that creates a cool evolution?\n If you enjoy logic, make a living doing something fun and be a programmer!";
            }
        }
           

        

       
    }

    void ResetDefaults()
    {
        //Default dropdown values
        ruleNumberOneState.value = 0;
        RuleNumberOneFilterValue = 2;
        RuleNumberOneResultingState = 1;
        ruleNumberTwoState.value = 0;
        RuleNumberTwoFilterValue1 = 2;
        RuleNumberTwoFilterValue2 = 3;
        RuleNumberTwoResultingState = 0;
        ruleNumberThreeState.value = 0;
        RuleNumberThreeFilterValue = 3;
        RuleNumberThreeResultingState = 1;
        ruleNumberFourState.value = 1;
        RuleNumberFourFilterValue = 3;
        RuleNumberFourResultingState = 0;

        //Toggles
        randomToggle.isOn = true;
        ToggleOne();
        btnRuleOne.Select();
    }

   
    public void ExitGame()
    {
        Application.Quit();
    }

    void ToggleOne()
    {
        int newPanelIndex = 0;
        int oldPanelIndex = 0;

        for (int i = 0; i < panels.Length; i++)
        {
            if (panels[i].name == "RuleNumberOne")
            {
                newPanelIndex = i;
            }

            if (panels[i].name == activePanel)
            {
                oldPanelIndex = i;
            }

           
       

        }

        // make the old panel invisible and the new panel visible.
        CanvasGroup oldPanelCG = panels[oldPanelIndex].GetComponent<CanvasGroup>();
        CanvasGroup newPanelCG = panels[newPanelIndex].GetComponent<CanvasGroup>();
        oldPanelCG.alpha = 0f;
        oldPanelCG.blocksRaycasts = false;

        newPanelCG.alpha = 1f;
        newPanelCG.blocksRaycasts = true;
        activePanel = panels[newPanelIndex].name;

        UpdateRuleText();
    }

    void ToggleTwo()
    {
        int newPanelIndex = 0;
        int oldPanelIndex = 0;

        for (int i = 0; i < panels.Length; i++)
        {
            if (panels[i].name == "RuleNumberTwo")
            {
                newPanelIndex = i;
            }

            if (panels[i].name == activePanel)
            {
                oldPanelIndex = i;
            }

            

        }

        // make the old panel invisible and the new panel visible.
        CanvasGroup oldPanelCG = panels[oldPanelIndex].GetComponent<CanvasGroup>();
        CanvasGroup newPanelCG = panels[newPanelIndex].GetComponent<CanvasGroup>();
        oldPanelCG.alpha = 0f;
        oldPanelCG.blocksRaycasts = false;

        newPanelCG.alpha = 1f;
        newPanelCG.blocksRaycasts = true;
        activePanel = panels[newPanelIndex].name;

        UpdateRuleText();
    }

    void ToggleThree()
    {
        int newPanelIndex = 0;
        int oldPanelIndex = 0;

        for (int i = 0; i < panels.Length; i++)
        {
            if (panels[i].name == "RuleNumberThree")
            {
                newPanelIndex = i;
            }

            if (panels[i].name == activePanel)
            {
                oldPanelIndex = i;
            }

          
        }

        // make the old panel invisible and the new panel visible.
        CanvasGroup oldPanelCG = panels[oldPanelIndex].GetComponent<CanvasGroup>();
        CanvasGroup newPanelCG = panels[newPanelIndex].GetComponent<CanvasGroup>();
        oldPanelCG.alpha = 0f;
        oldPanelCG.blocksRaycasts = false;

        newPanelCG.alpha = 1f;
        newPanelCG.blocksRaycasts = true;
        activePanel = panels[newPanelIndex].name;

        UpdateRuleText();
    }

    void ToggleFour()
    {
        int newPanelIndex = 0;
        int oldPanelIndex = 0;

        for (int i = 0; i < panels.Length; i++)
        {
            if (panels[i].name == "RuleNumberFour")
            {
                newPanelIndex = i;
            }

            if (panels[i].name == activePanel)
            {
                oldPanelIndex = i;
            }

           
        }

        // make the old panel invisible and the new panel visible.
        CanvasGroup oldPanelCG = panels[oldPanelIndex].GetComponent<CanvasGroup>();
        CanvasGroup newPanelCG = panels[newPanelIndex].GetComponent<CanvasGroup>();
        oldPanelCG.alpha = 0f;
        oldPanelCG.blocksRaycasts = false;

        newPanelCG.alpha = 1f;
        newPanelCG.blocksRaycasts = true;
        activePanel = panels[newPanelIndex].name;

        UpdateRuleText();
    }

    void ToggleInfo()
    {
        int newPanelIndex = 0;
        int oldPanelIndex = 0;

        for (int i = 0; i < panels.Length; i++)
        {
            if (panels[i].name == "GameInfo")
            {
                newPanelIndex = i;
            }

            if (panels[i].name == activePanel)
            {
                oldPanelIndex = i;
            }

            lblRuleText.text = "Can you devise a set of rules that creates a cool evolution?\n If you enjoy logic, make a living doing something fun and be a programmer!";
        }

        // make the old panel invisible and the new panel visible.
        CanvasGroup oldPanelCG = panels[oldPanelIndex].GetComponent<CanvasGroup>();
        CanvasGroup newPanelCG = panels[newPanelIndex].GetComponent<CanvasGroup>();
        oldPanelCG.alpha = 0f;
        oldPanelCG.blocksRaycasts = false;

        newPanelCG.alpha = 1f;
        newPanelCG.blocksRaycasts = true;
        activePanel = panels[newPanelIndex].name;
    }

    void Restart()
    {
        // logic for game restarts is contained in Game Controller.
        gameController.RestartGame();
        
    }

    #endregion

    // properties to represent the current value of UI controls.  Variables types must not be changed.
    #region Properties

    // must get/set a string equal to "Random", "Alive", or "Dead".
    public string CellStartingState
    {

        get
        {            
            if (randomToggle.isOn)
            {
                return "Random";
            }
            else if (aliveToggle.isOn)
            {
                return "Alive";
            }
            else
            {
                return "Dead";
            }
        }
        set
        {            
            if (value == "Random")
            {
                randomToggle.isOn = true;
                aliveToggle.isOn = false;
                deadToggle.isOn = false;
            }
            else if (value == "Alive")
            {
                aliveToggle.isOn = true;
                randomToggle.isOn = false;
                deadToggle.isOn = false;
            }
            else if (value == "Dead")
            {
                deadToggle.isOn = true;
                aliveToggle.isOn = false;
                randomToggle.isOn = false;
            }
        }
    }
   
    // must get/set integer value of 0 or 1
    public int RuleNumberOneState 
    {
        get
        {           
            return ruleNumberOneState.value;
        }
        set
        {            
            ruleNumberOneState.value = value;
        }

    }

    // must get/set integer value of 0-8
    public int RuleNumberOneFilterValue
    {
        get
        {            
            return ruleNumberOneFilterValue.value;
        }
        set
        {            
            ruleNumberOneFilterValue.value = value;
        }
    }

    // must get/set integer value of 0 or 1
    public int RuleNumberOneResultingState
    {
        get
        {           
            return ruleNumberOneResultingState.value;
        }
        set
        {
            
            ruleNumberOneResultingState.value = value;
        }
    }

    // must get/set integer value of 0 or 1
    public int RuleNumberTwoState
    {
        get
        {           
            return ruleNumberTwoState.value;
        }
        set
        {            
            ruleNumberTwoState.value = value;
        }
    }

    // must get/set integer value of 0-8
    public int RuleNumberTwoFilterValue1
    {
        get
        {            
            return ruleNumberTwoFilterValue1.value;
        }
        set
        {
            ruleNumberTwoFilterValue1.value = value;          
        }
    }

    // must get/set integer value of 0-8
    public int RuleNumberTwoFilterValue2
    {
        get
        {            
            return ruleNumberTwoFilterValue2.value;
        }
        set
        {
            
            ruleNumberTwoFilterValue2.value = value;
        }
    }
    // must get/set integer value of 0 or 1
    public int RuleNumberTwoResultingState
    {
        get
        {            
           return ruleNumberTwoResultingState.value;
        }
        set
        {            
           ruleNumberTwoResultingState.value = value;
        }
    }
    // must get/set integer value of 0 or 1
    public int RuleNumberThreeState
    {
        get
        {
            return ruleNumberThreeState.value;
        }
        set
        {
            ruleNumberThreeState.value = value;
        }
    }
    // must get/set integer value of 0-8
    public int RuleNumberThreeFilterValue
    {
        get
        {
            return ruleNumberThreeFilterValue.value;
        }
        set
        {
           ruleNumberThreeFilterValue.value = value;
        }
    }
    // must get/set integer value of 0 or 1
    public int RuleNumberThreeResultingState
    {
        get
        {
            return ruleNumberThreeResultingState.value;
        }
        set
        {
            ruleNumberThreeResultingState.value = value;
        }
    }
    // must get/set integer value of 0 or 1
    public int RuleNumberFourState
    {
        get
        {
            return ruleNumberFourState.value;
        }
        set
        {
            ruleNumberFourState.value = value;
        }
    }
    // must get/set integer value of 0-8
    public int RuleNumberFourFilterValue
    {
        get
        {
            return ruleNumberFourFilterValue.value;
        }
        set
        {
            ruleNumberFourFilterValue.value = value;
        }
    }
    // must get/set integer value of 0 or 1
    public int RuleNumberFourResultingState
    {
        get
        {
            return ruleNumberFourResultingState.value;
        }
        set
        {
            ruleNumberFourResultingState.value = value;
        }
    }
    // must return float value (0 - 100 used in testing)

    // must return integer (1-25 recommended)
    public int NumCubesX
    {
        get
        {
            int cubesX;
            bool valid = int.TryParse(numCubesX.text, out cubesX);
            if (valid == false)
            {
                cubesX = 10;
            } 

            if (cubesX > 25)
            {
               cubesX = 25;
            }
            if (cubesX < 1)
            {
                cubesX = 1;
            }

            numCubesX.text = cubesX.ToString();
            return cubesX;               
                
        }
        set
        {
            numCubesX.text = value.ToString();
        }
    }

    public int NumCubesY
    {
        get
        {
            int cubesY;
            bool valid = int.TryParse(numCubesY.text, out cubesY);
            if (valid == false)
            {
                cubesY = 10;
            }

            if (cubesY > 25)
            {
                cubesY = 25;
            }
            if (cubesY < 1)
            {
                cubesY = 1;
            }

            numCubesX.text = cubesY.ToString();
            return cubesY;
        }
        set
        {
            numCubesY.text = value.ToString();
        }
    }
    
    public float UpdateStateRateLimit
    {
        get
        {
            
            return speedSlider.value;
        }
        set
        {
            speedSlider = GameObject.FindObjectsOfType<Slider>().FirstOrDefault(sldr => sldr.name == "UpdateStateRateLimit").GetComponent<Slider>();
            speedSlider.value = value;
        }
    }
    #endregion Properties




}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System;

public class CubeController : MonoBehaviour
{
    private GameController gameController;

    // each cube controller will maintain its own list of neighbor cubes (3, 5, or 8 elements)
    private List<GameObject> neighborCubesList;
    
    // cubes can identify their own index based on their name
    private int thisCubeIndexX;
    private int thisCubeIndexY;

    private GameObject neighborCube;

    // to hold Game controller's master array of cubes.
    private GameObject[,] allCubes;

    // all calls made to UIController are through the interface
    private IUIController uiController;

    #region Rule Values
    private int ruleNumberOneState;
    private int ruleNumberOneFilterValue;
    private int ruleNumberOneResultingState;

    private int ruleNumberTwoState;
    private int ruleNumberTwoFilterValue1;
    private int ruleNumberTwoFilterValue2;
    private int ruleNumberTwoResultingState;

    private int ruleNumberThreeState;
    private int ruleNumberThreeFilterValue;
    private int ruleNumberThreeResultingState;

    private int ruleNumberFourState;
    private int ruleNumberFourFilterValue;
    private int ruleNumberFourResultingState;

    #endregion Rule Values

    // hold the number of live neighbors for use in state decision making.
    private int numLiveNeighbors;

    void Start ()
    {
        InitializeVariables();
        // calculate indexes of possible neighbor cubes using this cube's index.  Add cube to list if it exists.
        BuildNeighborCubeList();
        // get rule values from the ui and set local rule variables.
        SetRuleParameters();        
	}
	
	
	void Update ()
    {                
            // set this cube's NextState property based on number of live neighbors & rules.               
            SetState();     
   	}

    #region Worker Methods

    void InitializeVariables()
    {
        gameController = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameController>();
        uiController = GameObject.FindGameObjectWithTag("UIController").GetComponent<UIController>();

        // convert name converts string ("x,y") into integers x and y
        thisCubeIndexX = gameController.ConvertName(this.name, 'x');
        thisCubeIndexY = gameController.ConvertName(this.name, 'y');

        allCubes = gameController.CubeArray;
        neighborCubesList = new List<GameObject>();                
    }
    void BuildNeighborCubeList()
    {
        // the checkdirection helper methods return a gameobject or null.
        // if it is a gameobject, add it to the neighbor cube list.
        neighborCube = CheckNorthNeighborIndex();
        if (neighborCube != null)
        {
            neighborCubesList.Add(neighborCube);
        }
        
        neighborCube = CheckNorthWestNeighborIndex();
        if (neighborCube != null)
        {
            neighborCubesList.Add(neighborCube);
        }

        neighborCube = CheckWestNeighborIndex();
        if (neighborCube != null)
        {
            neighborCubesList.Add(neighborCube);
        }

        neighborCube = CheckSouthWestNeighborIndex();
        if (neighborCube != null)
        {
            neighborCubesList.Add(neighborCube);
        }

        neighborCube = CheckSouthNeighborIndex();
        if (neighborCube != null)
        {
            neighborCubesList.Add(neighborCube);
        }

        neighborCube = CheckSouthEastNeighborIndex();
        if (neighborCube != null)
        {
            neighborCubesList.Add(neighborCube);
        }

        neighborCube = CheckEastNeighborIndex();
        if (neighborCube != null)
        {
            neighborCubesList.Add(neighborCube);
        }

        neighborCube = CheckNorthEastNeighborIndex();
        if (neighborCube != null)
        {
            neighborCubesList.Add(neighborCube);
        }
    }

    void SetRuleParameters()
    {
        ruleNumberOneState = uiController.RuleNumberOneState;
        ruleNumberOneFilterValue = uiController.RuleNumberOneFilterValue;
        ruleNumberOneResultingState = uiController.RuleNumberOneResultingState;

        ruleNumberTwoState = uiController.RuleNumberTwoState;
        ruleNumberTwoFilterValue1 = uiController.RuleNumberTwoFilterValue1;
        ruleNumberTwoFilterValue2 = uiController.RuleNumberTwoFilterValue2;
        ruleNumberTwoResultingState = uiController.RuleNumberTwoResultingState;

        ruleNumberThreeState = uiController.RuleNumberThreeState;
        ruleNumberThreeFilterValue = uiController.RuleNumberThreeFilterValue;
        ruleNumberThreeResultingState = uiController.RuleNumberThreeResultingState;

        ruleNumberFourState = uiController.RuleNumberFourState;
        ruleNumberFourFilterValue = uiController.RuleNumberFourFilterValue;
        ruleNumberFourResultingState = uiController.RuleNumberFourResultingState;
}

    void SetState()
    {               
        
        numLiveNeighbors = 0;
        CubeController cubeController;
        
        // determine how many neighbor cubes are alive.
        foreach (GameObject cube in neighborCubesList)
        {
            cubeController = cube.GetComponent<CubeController>();
            if (cubeController.State == 0)
            {
                numLiveNeighbors += 1;               
            }
        }

        // rule number one - if the cell is <state> and has fewer than <filtervalue> living neighbors, it <resulting state>.
        if (this.State == ruleNumberOneState && numLiveNeighbors < ruleNumberOneFilterValue)
        {
            this.NextState = ruleNumberOneResultingState;
        }

        // rule number two - if the cell is <state> and has between <filtervalue1> & <filtervalue2> live neighbors, it <resulting state>.
        if (this.State == ruleNumberTwoState && numLiveNeighbors >= ruleNumberTwoFilterValue1 && numLiveNeighbors <= ruleNumberTwoFilterValue2)
        {
            this.NextState = ruleNumberTwoResultingState;
        }

        // rule number three - if a cell is <state> and has greater than three <filtervalue> neighbors, it <resulting state>.
        if (this.State == ruleNumberThreeState && numLiveNeighbors > ruleNumberThreeFilterValue)
        {
            this.NextState = ruleNumberThreeResultingState;
        }

        // rule number four - if a cell is <state> and has exactly <filtervalue> neighbors, it <resulting state>.
        if (this.State == ruleNumberFourState && numLiveNeighbors == ruleNumberFourFilterValue)
        {
            this.NextState = ruleNumberFourResultingState;
        }
       
        
    }
    #endregion Worker Methods

    #region Helper Methods

    // the check position methods return a game object if one exists at the neighbor index position.
    // isValidIndex makes sure that the calculated neighbor position is not out of bounds.
    private GameObject CheckNorthNeighborIndex()
    {
        int neighborX = thisCubeIndexX;
        int neighborY = thisCubeIndexY + 1;
        bool isValid = isValidIndex(neighborX, neighborY);

        if (isValid)
        {
            neighborCube = allCubes[neighborX, neighborY];
            return neighborCube;
        }
        else
        {
            return null;
        }        
        
    }

    private GameObject CheckNorthWestNeighborIndex()
    {
        int neighborX = thisCubeIndexX - 1;
        int neighborY = thisCubeIndexY + 1;
        bool isValid = isValidIndex(neighborX, neighborY);

        if (isValid)
        {
            neighborCube = allCubes[neighborX, neighborY];
            return neighborCube;
        }
        else
        {
            return null;
        }        
    }

    private GameObject CheckWestNeighborIndex()
    {
        int neighborX = thisCubeIndexX - 1;
        int neighborY = thisCubeIndexY;
        bool isValid = isValidIndex(neighborX, neighborY);

        if (isValid)
        {
            neighborCube = allCubes[neighborX, neighborY];
            return neighborCube;
        }
        else
        {
            return null;
        }               
    }

    private GameObject CheckSouthWestNeighborIndex()
    {
        int neighborX = thisCubeIndexX - 1;
        int neighborY = thisCubeIndexY - 1;
        bool isValid = isValidIndex(neighborX, neighborY);

        if (isValid)
        {
            neighborCube = allCubes[neighborX, neighborY];
            return neighborCube;
        }
        else
        {
            return null;
        }       
          
    }   

    private GameObject CheckSouthNeighborIndex()
    {
        int neighborX = thisCubeIndexX;
        int neighborY = thisCubeIndexY - 1;
        bool isValid = isValidIndex(neighborY, neighborX);

        if (isValid)
        {
            neighborCube = allCubes[neighborX, neighborY];
            return neighborCube;
        }
        else
        {
            return null;
        }
    }

    private GameObject CheckSouthEastNeighborIndex()
    {
        int neighborX = thisCubeIndexX + 1;
        int neighborY = thisCubeIndexY - 1;
        bool isValid = isValidIndex(neighborX, neighborY);

        if (isValid)
        {
            neighborCube = allCubes[neighborX, neighborY];
            return neighborCube;
        }   
        else
        {
            return null;
        }
    }

    private GameObject CheckEastNeighborIndex()
    {
        int neighborX = thisCubeIndexX + 1;
        int neighborY = thisCubeIndexY;
        bool isValid = isValidIndex(neighborX, neighborY);

        if (isValid)
        {
            neighborCube = allCubes[neighborX, neighborY];
            return neighborCube;
        }                  
        else
        {
            return null;
        }
    }

    private GameObject CheckNorthEastNeighborIndex()
    {
        int neighborX = thisCubeIndexX + 1;
        int neighborY = thisCubeIndexY + 1;
        bool isValid = isValidIndex(neighborX, neighborY);

        if (isValid)
        {
            neighborCube = allCubes[neighborX, neighborY];
            return neighborCube;
        }
        else
        {
            return null;
        }
    }
   
    public bool isValidIndex(int x, int y)
    {       
        
        if (x < allCubes.GetLowerBound(0) ||
            x > allCubes.GetUpperBound(0) ||
            y < allCubes.GetLowerBound(1) ||
            y > allCubes.GetUpperBound(1))
            return false;
        return true;
    }

    #endregion Helper Methods


    // current state
    public int State { get; set; }

    // state that the cell will be set to in Game Controller's ChangeCubeStates() method
    public int NextState { get; set; }
}

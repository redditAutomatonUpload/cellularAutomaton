﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CameraController : MonoBehaviour
{
    
    public float camY;   
      
    // moves the camera to be centered over the approximate center of the cube grid.
    // this can be modified and will have no effect on the other classes.
    void Start ()
    {
        GameController gameController = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameController>();       
        
        float posZ = gameController.CubeArray.GetLength(1) / 2;
        
        Vector3 camPOS = new Vector3(0, camY, posZ);
        transform.position = camPOS;      
    }
	
	void Update ()
    {
		
	}
}

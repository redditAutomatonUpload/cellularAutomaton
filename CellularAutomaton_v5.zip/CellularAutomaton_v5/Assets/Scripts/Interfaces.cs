﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// this interface defines what is needed from the UIController to work with the GameController and CubeController.
// the interface is very open to customization, as long as it contains controls that can hold these values,
// and these properties expose those values, it will work.  also needs an Initialize() method that can be called
// from GameController.
    public interface IUIController
    {
    // must get/set a string equal to "Random", "Alive", or "Dead".
    string CellStartingState { get; set;  }

    // must get/set integer value of 0 or 1
    int RuleNumberOneState { get; set; }

    // must get/set integer value of 0-8
    int RuleNumberOneFilterValue { get; set; }

    // must get/set integer value of 0 or 1
    int RuleNumberOneResultingState { get; set; }

    // must get/set integer value of 0 or 1
    int RuleNumberTwoState { get; set; }

    // must get/set integer value of 0-8
    int RuleNumberTwoFilterValue1 { get; set; }

    // must get/set integer value of 0-8
    int RuleNumberTwoFilterValue2 { get; set; }

    // must get/set integer value of 0 or 1
    int RuleNumberTwoResultingState { get; set; }

    // must get/set integer value of 0 or 1
    int RuleNumberThreeState { get; set; }

    // must get/set integer value of 0-8
    int RuleNumberThreeFilterValue { get; set; }

    // must get/set integer value of 0 or 1
    int RuleNumberThreeResultingState { get; set; }

    // must get/set integer value of 0 or 1
    int RuleNumberFourState { get; set; }

    // must get/set integer value of 0-8
    int RuleNumberFourFilterValue { get; set; }

    // must get/set integer value of 0 or 1
    int RuleNumberFourResultingState { get; set; }

    // must get/set float value (recommended 0 - 100)
    float UpdateStateRateLimit { get;  set;}

    // must get/set integer value (recommended 1-25)
    int NumCubesX { get; set; }

    // must get/set integer value (recommended 1-25)
    int NumCubesY { get; set; }

    // must initialize UI components so that it can be called in Game Controller's Awake()
    void InitializeUI();
    
}

	


﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.SceneManagement;
using System;

public class GameController : MonoBehaviour
{
    // publics to be modified by testing.  spacing and grid sizes can be converted to private for final build.
    public GameObject CubePrefab;
    public float CubeSpacing;

    // gridsizes set by ui controls
    private static int gridSizeX = 17;
    private static int gridSizeY = 17;

   // to modify cube states and colors.
    private CubeController cubeController;
    private Renderer rend;

    // use interface to interact with UI.
    private IUIController uiController;

    // gamespeed: 0 = full speed, 100 = slowest.  frameCount is just to work with gameSpeed to control update rate.
    private static string startingCellState = "Random";
    private static float gameSpeed = 0;
    private int frameCount;   
    
    // static variables to hold UI values for state rules.
    #region Rule Values 
    private static int ruleNumberOneState = 0;
    private static int ruleNumberOneFilterValue = 2;
    private static int ruleNumberOneResultingState = 1;

    private static int ruleNumberTwoState = 0;
    private static int ruleNumberTwoFilterValue1 = 2;
    private static int ruleNumberTwoFilterValue2 = 3;
    private static int ruleNumberTwoResultingState = 0;

    private static int ruleNumberThreeState = 0;
    private static int ruleNumberThreeFilterValue = 3;
    private static int ruleNumberThreeResultingState = 1;

    private static int ruleNumberFourState = 1;
    private static int ruleNumberFourFilterValue = 3;
    private static int ruleNumberFourResultingState = 0;

    #endregion    

    private void Awake()
    {
        //Set screen resolution so that we can avoid the popup options window on start.
        Screen.SetResolution(1366, 768, true, 60);

        // function for initializing variables that will be called in later processes.
        InitializeVariables();

        // need to initialize the UI to avoid calling properties that haven't been initialized.
        uiController.InitializeUI();

        // instantiate cubes, name cubes, populate CubeArray, set initial cube states.
        CreateCubeGrid();

        // needs to run once before the update cycles to set initial cube color.
        ChangeCubeColors();

        // at the start of a new game, set UI control values equal to static variables in GameController.
        PopulateUI();
    }


    void Start()
    {

    }

    private void LateUpdate()
    {
        // cubes set their NextState property every Update, but GameController will only change States on Late Update.
        // late update happens after all Updates have completed for all game objects.
        // control the rate at which State changes are applid by using slider/changing gameSpeed variable.
        gameSpeed = uiController.UpdateStateRateLimit;
        if (frameCount >= gameSpeed)
        {
            frameCount = 0;

            // change all the cube state at once to their new state.
            ChangeCubeStates();

            // set cube color based on state.
            ChangeCubeColors();
        }
        else // frameCount increments if this Late Update was skipped.
        {
            frameCount += 1;
        }
    
    }        
    
    void Update()
    {

    }

    #region Worker Methods

    void InitializeVariables()
    {
        frameCount = 0;
        uiController = GameObject.FindGameObjectWithTag("UIController").GetComponent<IUIController>();       
        CubeArray = new GameObject[gridSizeX, gridSizeY];
    }
    void CreateCubeGrid()
    {
        Vector3 pos;
        GameObject cube;
        
        for (int y = 0; y < gridSizeY; y++)
        {
            for (int x = 0; x < gridSizeX; x++)
            {

                // set the cube's position equal to its index * how far apart we want them.
                pos = new Vector3(x, 0, y + 2) * CubeSpacing;
                cube = Instantiate(CubePrefab, pos, Quaternion.identity);

                // name the cube after its index
                cube.name = string.Format("{0},{1}", x, y);                         
                CubeArray[x, y] = cube;

                // get the cube's controller and set its state based on UI settings.
                cubeController = cube.GetComponent<CubeController>();
                if (startingCellState == "Random")
                {

                    int r = UnityEngine.Random.Range(0, 2);
                    cubeController.State = r;
                }
                else if (startingCellState == "Alive")
                {
                    cubeController.State = 0;
                }
                else if (startingCellState == "Dead")
                {
                    cubeController.State = 1;
                }               
              
            }
        }
    }

    void PopulateUI()
    {
        uiController.NumCubesX = gridSizeX;
        uiController.NumCubesY = gridSizeY;
        uiController.CellStartingState = startingCellState;

        uiController.RuleNumberOneState = ruleNumberOneState;
        uiController.RuleNumberOneFilterValue = ruleNumberOneFilterValue;
        uiController.RuleNumberOneResultingState = ruleNumberOneResultingState;

        uiController.RuleNumberTwoState = ruleNumberTwoState;
        uiController.RuleNumberTwoFilterValue1 = ruleNumberTwoFilterValue1;
        uiController.RuleNumberTwoFilterValue2 = ruleNumberTwoFilterValue2;
        uiController.RuleNumberTwoResultingState = ruleNumberTwoResultingState;

        uiController.RuleNumberThreeState = ruleNumberThreeState;
        uiController.RuleNumberThreeFilterValue = ruleNumberThreeFilterValue;
        uiController.RuleNumberThreeResultingState = ruleNumberThreeResultingState;

        uiController.RuleNumberFourState = ruleNumberFourState;
        uiController.RuleNumberFourFilterValue = ruleNumberFourFilterValue;
        uiController.RuleNumberFourResultingState = ruleNumberFourResultingState;

        uiController.UpdateStateRateLimit = gameSpeed;
    }

    void ChangeCubeStates()
    {
        foreach (GameObject cube in CubeArray)
        {
            cubeController = cube.GetComponent<CubeController>();
            cubeController.State = cubeController.NextState;
        }
        
    }
    void ChangeCubeColors()
    {
        
        foreach (GameObject cube in CubeArray)
        {
                cubeController = cube.GetComponent<CubeController>();
                rend = cube.GetComponent<Renderer>();

                if (cubeController.State == 0)
                {
                    rend.material.color = Color.white;
                }
                else
                {
                    rend.material.color = Color.black;
                }
            }       

    }

    public void RestartGame()  
    {

        ruleNumberOneState = uiController.RuleNumberOneState;
        ruleNumberOneFilterValue = uiController.RuleNumberOneFilterValue;
        ruleNumberOneResultingState = uiController.RuleNumberOneResultingState;

        ruleNumberTwoState = uiController.RuleNumberTwoState;
        ruleNumberTwoFilterValue1 = uiController.RuleNumberTwoFilterValue1;
        ruleNumberTwoFilterValue2 = uiController.RuleNumberTwoFilterValue2;
        ruleNumberTwoResultingState = uiController.RuleNumberTwoResultingState;

        ruleNumberThreeState = uiController.RuleNumberThreeState;
        ruleNumberThreeFilterValue = uiController.RuleNumberThreeFilterValue;
        ruleNumberThreeResultingState = uiController.RuleNumberThreeResultingState;

        ruleNumberFourState = uiController.RuleNumberFourState;
        ruleNumberFourFilterValue = uiController.RuleNumberFourFilterValue;
        ruleNumberFourResultingState = uiController.RuleNumberFourResultingState;

        startingCellState = uiController.CellStartingState;
        gridSizeX = uiController.NumCubesX;
        gridSizeY = uiController.NumCubesY;

        gameSpeed = uiController.UpdateStateRateLimit;

        SceneManager.LoadScene("Main");

    }
    
    #endregion Worker Methods

    #region Helper Methods
    public int ConvertName(string name, char axis)
    {
        int convertedAxis;

        if (axis == 'y')
        {           
            convertedAxis = Int32.Parse(name.Substring(name.LastIndexOf(',') + 1));            
        }
        else
        {           
            convertedAxis = Int32.Parse(name.Substring(0, name.IndexOf(',')));            
        }

        return convertedAxis;

    }
    #endregion Helper Methods

    public GameObject[,] CubeArray;

}
